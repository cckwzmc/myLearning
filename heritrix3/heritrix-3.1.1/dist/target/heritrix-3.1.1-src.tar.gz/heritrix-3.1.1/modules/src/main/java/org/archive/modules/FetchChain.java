package org.archive.modules;

public class FetchChain extends ProcessorChain {

}
