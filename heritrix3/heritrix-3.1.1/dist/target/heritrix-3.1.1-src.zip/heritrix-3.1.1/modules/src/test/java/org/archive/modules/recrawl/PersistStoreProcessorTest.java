package org.archive.modules.recrawl;

import org.archive.state.ModuleTestBase;

/**
 * @author pjack
 */
public class PersistStoreProcessorTest extends ModuleTestBase {

    public void testHistory() {
        //TODO: tests
    }
}
